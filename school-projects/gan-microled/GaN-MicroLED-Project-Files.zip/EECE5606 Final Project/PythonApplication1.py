from phidl import Device, Layer, LayerSet, make_device
from phidl import quickplot as qp # Rename "quickplot()" to the easier "qp()"
import phidl.geometry as pg
import phidl.routing as pr
import phidl.utilities as pu
import matplotlib.pyplot as plot




def LED_Struct(length, xpoint, ypoint):
    LED = Device ('Test Device')


    xpts1 = (xpoint,xpoint+length,xpoint+length, xpoint)
    ypts1 = (ypoint, ypoint, ypoint+length/2, ypoint+length/2)
    poly1 = LED.add_polygon([xpts1, ypts1], layer = 0)

    xpts2 = (xpoint+length*(7/24), xpoint+length*(17/24), xpoint+length*(17/24), xpoint+length*(7/24))
    ypts2 = (ypoint, ypoint, ypoint + length/2, ypoint + length/2)
    poly2 = LED.add_polygon([xpts2, ypts2], layer = 1)


    xpts3 = (xpoint,xpoint+length*(3.5/24),xpoint+length*(3.5/24), xpoint)
    ypts3 = (ypoint, ypoint, ypoint+length/2, ypoint+length/2)
    poly3 = LED.add_polygon([xpts3, ypts3], layer = 2)

    xpts4 = (xpoint+length*(20.5/24),xpoint+length,xpoint+length, xpoint+length*(20.5/24))
    ypts4 = (ypoint, ypoint, ypoint+length/2, ypoint+length/2)
    poly4 = LED.add_polygon([xpts4, ypts4], layer = 2)


    xpts5 = (xpoint+length*(3.5/24),xpoint+length*(17/24),xpoint+length*(17/24), xpoint+length*(3.5/24))
    ypts5 = (ypoint+length*(5.5/24), ypoint+length*(5.5/24), ypoint+length*(6.5/24), ypoint+length*(6.5/24))
    poly5 = LED.add_polygon([xpts5, ypts5], layer = 2)


    xpts6 = (xpoint+length*(11.5/24),xpoint+length*(12.5/24),xpoint+length*(12.5/24), xpoint+length*(11.5/24))
    ypts6 = (ypoint, ypoint, ypoint+length/2, ypoint+length/2)
    poly6 = LED.add_polygon([xpts6, ypts6], layer = 2)


    res_star = pg.litho_star(5,length/24, length/2, layer=2)  #size is outer diameter in microns equal to smallest feature length of star (1/18)length
    star_ref = LED.add_ref(res_star)
    star_ref.move(destination=(xpoint+length*(2), ypoint+length/4))



    qp(LED) # quickplot the geometry
    plot.show()
    return(LED)
    



l = 10
x = 0
y = 0

l2=20
x2=0
y2=40

l3=30
x3=0
y3=80

l4=100
x4=0
y4=100



# Create a top-level device
Top = Device('Top Layout')

# Generate your two LED structures
D1 = LED_Struct(l, x, y)
D2 = LED_Struct(l2, x2, y2)
D3 = LED_Struct(l3, x3, y3)
D4 = LED_Struct(l4, x3, y4)

# Add them as references into the top device
Top.add_ref(D1)
Top.add_ref(D2)
Top.add_ref(D3)
Top.add_ref(D4)

# Write to GDS once
Top.write_gds('text.gds')